package com.example.authService.services;

import com.example.authService.configs.JwtUtil;
import com.example.authService.dtos.LoginRequestDto;
import com.example.authService.dtos.LoginResponseDto;
import com.example.authService.dtos.RegisterRequest;
import com.example.authService.entities.User;
import com.example.authService.entities.UserRole;
import com.example.authService.exceptions.UserNotFoundException;
import com.example.authService.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AuthService authService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void login_ShouldReturnJwtToken_WhenCredentialsAreValid() {
        // Arrange
        LoginRequestDto request = new LoginRequestDto("testUser", "password123");
        User user = new User();
        user.setUsername("testUser");
        user.setPassword("encodedPassword");

        when(userRepository.findByUsername(request.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(request.getPassword(), user.getPassword())).thenReturn(true);
        when(jwtUtil.generateToken(user.getUsername(), String.valueOf(user.getRole()))).thenReturn("mockJwtToken");

        // Act
        LoginResponseDto response = authService.login(request);

        // Assert
        assertNotNull(response);
        assertEquals("mockJwtToken", response.getToken());
        verify(userRepository, times(1)).findByUsername(request.getUsername());
        verify(passwordEncoder, times(1)).matches(request.getPassword(), user.getPassword());
        verify(jwtUtil, times(1)).generateToken(user.getUsername(), String.valueOf(user.getRole()));
    }

    @Test
    void login_ShouldThrowException_WhenUsernameNotFound() {
        // Arrange
        LoginRequestDto request = new LoginRequestDto("invalidUser", "password123");
        when(userRepository.findByUsername(request.getUsername())).thenReturn(Optional.empty());

        // Act & Assert
        UserNotFoundException exception = assertThrows(UserNotFoundException.class, () -> authService.login(request));
        assertEquals("Invalid username", exception.getMessage());
        verify(userRepository, times(1)).findByUsername(request.getUsername());
        verify(passwordEncoder, never()).matches(anyString(), anyString());
        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }

    @Test
    void login_ShouldThrowException_WhenPasswordIsIncorrect() {
        // Arrange
        LoginRequestDto request = new LoginRequestDto("testUser", "wrongPassword");
        User user = new User();
        user.setUsername("testUser");
        user.setPassword("encodedPassword");

        when(userRepository.findByUsername(request.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(request.getPassword(), user.getPassword())).thenReturn(false);

        // Act & Assert
        UserNotFoundException exception = assertThrows(UserNotFoundException.class, () -> authService.login(request));
        assertEquals("Invalid password", exception.getMessage());
        verify(userRepository, times(1)).findByUsername(request.getUsername());
        verify(passwordEncoder, times(1)).matches(request.getPassword(), user.getPassword());
        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }
    @Test
    void register_ShouldSaveUser_WhenValidRequestIsProvided() {
        // Arrange
        RegisterRequest request = new RegisterRequest();
        request.setName("Test User");
        request.setUsername("testUser");
        request.setEmail("test@example.com");
        request.setPassword("password123");

        User userEntity = User.builder()
                .name(request.getName())
                .username(request.getUsername())
                .email(request.getEmail())
                .password("encodedPassword")
                .role(UserRole.CUSTOMER) // Ensure role is set if required
                .build();

        // Mock password encoding
        when(passwordEncoder.encode(request.getPassword())).thenReturn("encodedPassword");

        // Mock ModelMapper behavior
        when(modelMapper.map(request, User.class)).thenReturn(userEntity);

        // Mock repository save behavior
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        authService.register(request);

        // Assert
        verify(passwordEncoder, times(1)).encode(request.getPassword());
        verify(modelMapper, times(1)).map(request, User.class);
        verify(userRepository, times(1)).save(any(User.class));

        // Additional validation to ensure correct mapping
        assertEquals("Test User", userEntity.getName());
        assertEquals("testUser", userEntity.getUsername());
        assertEquals("test@example.com", userEntity.getEmail());
        assertEquals("encodedPassword", userEntity.getPassword());
        assertEquals(UserRole.CUSTOMER, userEntity.getRole());
    }
}