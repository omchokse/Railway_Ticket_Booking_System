package com.example.authService.controller;

import com.example.authService.dtos.LoginRequestDto;
import com.example.authService.dtos.LoginResponseDto;
import com.example.authService.dtos.RegisterRequest;
import com.example.authService.interfaces.IAuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuthControllerTest {

    @Mock
    private IAuthService authService;

    @InjectMocks
    private AuthController authController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void login_ShouldReturnLoginResponseDto_WhenCredentialsAreValid() {
        // Arrange
        LoginRequestDto request = new LoginRequestDto("testUser", "password123");
        LoginResponseDto expectedResponse = new LoginResponseDto("mockJwtToken");
        when(authService.login(request)).thenReturn(expectedResponse);

        // Act
        ResponseEntity<LoginResponseDto> response = authController.login(request);

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(expectedResponse, response.getBody());
        verify(authService, times(1)).login(request);
    }

    @Test
    void register_ShouldReturnSuccessMessage_WhenRegistrationIsSuccessful() {
        // Arrange
        RegisterRequest request = new RegisterRequest();
        request.setName("Test User");
        request.setUsername("testUser");
        request.setEmail("test@example.com");
        request.setPassword("password123");

        doNothing().when(authService).register(request);

        // Act
        ResponseEntity<String> response = authController.register(request);

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("User registered successfully", response.getBody());
        verify(authService, times(1)).register(request);
    }
}