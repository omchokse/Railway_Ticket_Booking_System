package com.example.authService.services;

import com.example.authService.configs.JwtUtil;
import com.example.authService.dtos.LoginRequestDto;
import com.example.authService.dtos.LoginResponseDto;
import com.example.authService.dtos.RegisterRequest;
import com.example.authService.entities.User;
import com.example.authService.exceptions.UserNotFoundException;
import com.example.authService.interfaces.IAuthService;
import com.example.authService.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Slf4j
@Service
public class AuthService implements IAuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public LoginResponseDto login(LoginRequestDto request) {
        log.info("Attempting login for username: {}", request.getUsername());

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> {
                    log.error("Login failed: username not found - {}", request.getUsername());
                    return new UserNotFoundException("Invalid username");
                });

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.error("Login failed: incorrect password for username {}", request.getUsername());
            throw new UserNotFoundException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getUsername(), String.valueOf(user.getRole()));
        log.info("Login successful for username: {}", request.getUsername());
        return new LoginResponseDto(token);
    }

    @Override
    public void register(RegisterRequest user) {
        log.info("Attempting registration for username: {}", user.getUsername());

        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        log.debug("Encoded password for username: {}", user.getUsername());

        User userEntity = modelMapper.map(user, User.class);
        userRepository.save(userEntity);

        log.info("User registered successfully: {}", user.getUsername());
    }
}
