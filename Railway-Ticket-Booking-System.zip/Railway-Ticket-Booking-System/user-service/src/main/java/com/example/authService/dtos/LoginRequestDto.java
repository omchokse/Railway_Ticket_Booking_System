/**
 * Data Transfer Object (DTO) used for user login requests.
 * <p>
 * This class carries the login credentials: username and password,
 * and includes validation constraints to ensure data integrity.
 */
package com.example.authService.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginRequestDto {

    @NotNull(message = "Username must not be null")
    @NotBlank(message = "Username must not be empty")
    private String username;

    @NotNull(message = "Password must not be null")
    @NotBlank(message = "Password must not be empty")
    private String password;
}
