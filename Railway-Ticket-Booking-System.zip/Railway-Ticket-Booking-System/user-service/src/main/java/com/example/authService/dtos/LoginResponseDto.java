/**
 * Data Transfer Object (DTO) used for the response after a successful user login.
 * <p>
 * This class contains the JWT token that is returned to the user after successful authentication.
 */
package com.example.authService.dtos;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginResponseDto {
    private String token;
}
