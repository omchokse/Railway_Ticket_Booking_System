package com.example.authService.entities;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
