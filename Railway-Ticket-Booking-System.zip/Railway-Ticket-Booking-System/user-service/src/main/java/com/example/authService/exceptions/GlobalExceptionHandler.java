package com.example.authService.exceptions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for the authentication service.
 * <p>
 * This class handles exceptions thrown across the whole application and provides
 * consistent and meaningful HTTP responses.
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles UserNotFoundException which typically occurs during login when
     * the username or password is invalid.
     *
     * @param ex the thrown UserNotFoundException
     * @return a 401 Unauthorized response with the error message
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException ex) {
        log.warn("UserNotFoundException caught: {}", ex.getMessage());
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
    }

    /**
     * Handles DataIntegrityViolationException which typically occurs during
     * registration when there is a conflict such as duplicate user data or null constraints.
     *
     * @param ex the thrown DataIntegrityViolationException
     * @return a detailed response with an appropriate HTTP status
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Object> handleDataIntegrityViolation(DataIntegrityViolationException ex) {
        log.warn("DataIntegrityViolationException caught: {}", ex.getMessage(), ex);

        Map<String, Object> response = new HashMap<>();
        HttpStatus status = HttpStatus.BAD_REQUEST;

        if (ex.getRootCause() != null && ex.getRootCause().getMessage() != null) {
            String rootMsg = ex.getRootCause().getMessage().toLowerCase();

            if (rootMsg.contains("duplicate") || rootMsg.contains("unique")) {
                response.put("error", "Conflict");
                response.put("message", "A user with the provided details already exists. Please use different values.");
                status = HttpStatus.CONFLICT;
            } else if (rootMsg.contains("null")) {
                response.put("error", "Bad Request");
                response.put("message", "A required field is missing or contains an invalid value. Please review your input.");
                status = HttpStatus.BAD_REQUEST;
            }
        } else {
            response.put("error", "Data Integrity Violation");
            response.put("message", "An unexpected database constraint violation occurred.");
        }

        return new ResponseEntity<>(response, status);
    }

    /**
     * Handles validation errors from @Valid annotated DTOs.
     *
     * @param ex the thrown MethodArgumentNotValidException
     * @return a map of field names and corresponding error messages with 400 Bad Request
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage())
        );
        log.warn("Validation errors occurred: {}", errors);
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles all unhandled exceptions to avoid exposing stack traces to the client.
     *
     * @param ex the thrown Exception
     * @return a generic 500 Internal Server Error response
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGeneralException(Exception ex) {
        log.error("Unhandled exception caught: ", ex);
        return new ResponseEntity<>("Something went wrong! " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
