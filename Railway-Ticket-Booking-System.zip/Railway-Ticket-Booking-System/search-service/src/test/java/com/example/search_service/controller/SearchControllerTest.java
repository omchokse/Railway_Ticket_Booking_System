package com.example.search_service.controller;

import com.example.search_service.feign.TrainServiceClient;
import com.example.search_service.model.Train;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class SearchControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TrainServiceClient trainServiceClient;

    @InjectMocks
    private SearchController searchController;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(searchController).build();
    }

    @Test
    void searchTrains() throws Exception {
        Train train1 = new Train();
        train1.setSource("Mumbai");
        train1.setDestination("Delhi");

        Train train2 = new Train();
        train2.setSource("Mumbai");
        train2.setDestination("Pune");

        List<Train> allTrains = Arrays.asList(train1, train2);
        when(trainServiceClient.getAllTrains()).thenReturn(allTrains);

        mockMvc.perform(get("/search/trains")
                        .param("source", "Mumbai")
                        .param("destination", "Delhi")
                        .param("date", "2025-05-01"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));

        verify(trainServiceClient, times(1)).getAllTrains();
    }
}