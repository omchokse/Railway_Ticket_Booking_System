package com.example.search_service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Train {
    private Long id;
    private String trainNumber;
    private String source;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private double baseFare;
    private double distanceInKm;
    private LocalDate travelDate;
}

//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getTrainNumber() {
//        return trainNumber;
//    }
//
//    public void setTrainNumber(String trainNumber) {
//        this.trainNumber = trainNumber;
//    }
//
//    public String getSource() {
//        return source;
//    }
//
//    public void setSource(String source) {
//        this.source = source;
//    }
//
//    public String getDestination() {
//        return destination;
//    }
//
//    public void setDestination(String destination) {
//        this.destination = destination;
//    }
//
//    public String getDepartureTime() {
//        return departureTime;
//    }
//
//    public void setDepartureTime(String departureTime) {
//        this.departureTime = departureTime;
//    }
//
//    public String getArrivalTime() {
//        return arrivalTime;
//    }
//
//    public void setArrivalTime(String arrivalTime) {
//        this.arrivalTime = arrivalTime;
//    }
//
//    public double getBaseFare() {
//        return baseFare;
//    }
//
//    public void setBaseFare(double baseFare) {
//        this.baseFare = baseFare;
//    }
//
//    public double getDistanceInKm() {
//        return distanceInKm;
//    }
//
//    public void setDistanceInKm(double distanceInKm) {
//        this.distanceInKm = distanceInKm;
//    }
//
//    public LocalDate getTravelDate() {
//        return travelDate;
//    }
//
//    public void setTravelDate(LocalDate travelDate) {
//        this.travelDate = travelDate;
//    }
//}
