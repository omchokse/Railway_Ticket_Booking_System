package com.example.search_service.controller;

import com.example.search_service.feign.TrainServiceClient;
import com.example.search_service.model.Train;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/search")
@Slf4j
public class SearchController {

    @Autowired
    private TrainServiceClient trainServiceClient;

    @GetMapping("/trains")
    public List<Train> searchTrains(@RequestParam String source,
                                    @RequestParam String destination,
                                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate)
    {
        try {
            List<Train> allTrains = trainServiceClient.getAllTrains();

            List<Train> filteredTrains = allTrains.stream()
                    .filter(train -> train.getSource().equalsIgnoreCase(source)
                            && train.getDestination().equalsIgnoreCase(destination)
                            && train.getTravelDate().equals(travelDate))
                    .collect(Collectors.toList());

            if (filteredTrains.isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No trains found for the given criteria");
            }
            log.info("Trains searched successfully");
            return filteredTrains;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error occurred while searching for trains", e);
        }
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleGeneralException(Exception e) {
        return "An error occurred: " + e.getMessage();
    }
}