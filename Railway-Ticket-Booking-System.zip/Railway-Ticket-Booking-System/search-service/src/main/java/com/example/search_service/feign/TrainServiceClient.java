package com.example.search_service.feign;

import com.example.search_service.model.Train;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "train-service")
public interface TrainServiceClient {

    @GetMapping("/trains")
    List<Train> getAllTrains();

    @GetMapping("/trains/{trainId}")
    Train getTrainById(@PathVariable Long trainId);

    @GetMapping("/trains/fare/{trainId}/{travelClass}")
    double getFare(@PathVariable Long trainId, @PathVariable String travelClass);
}
