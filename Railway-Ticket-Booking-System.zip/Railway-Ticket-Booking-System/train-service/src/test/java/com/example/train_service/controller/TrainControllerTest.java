package com.example.train_service.controller;

import com.example.train_service.entity.Train;
import com.example.train_service.repository.TrainRepository;
import com.example.train_service.service.FareService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TrainControllerTest {

    @Mock
    private TrainRepository trainRepository;

    @Mock
    private FareService fareService;

    @InjectMocks
    private TrainController trainController;

    private Train train;

    @BeforeEach
    void setUp() {
        train = new Train();
        train.setId(1L);
        train.setDistanceInKm(500);
    }

    @Test
    void testAddTrain() {
        when(trainRepository.save(train)).thenReturn(train);
        Train savedTrain = trainController.addTrain(train);
        assertEquals(train, savedTrain);
        verify(trainRepository, times(1)).save(train);
    }

    @Test
    void testGetAllTrains() {
        when(trainRepository.findAll()).thenReturn(List.of(train));
        List<Train> trains = trainController.getAllTrains();
        assertFalse(trains.isEmpty());
        assertEquals(1, trains.size());
        verify(trainRepository, times(1)).findAll();
    }

    @Test
    void testGetTrainById() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));
        Train foundTrain = trainController.getTrainById(1L);
        assertEquals(train, foundTrain);
        verify(trainRepository, times(1)).findById(1L);
    }

    @Test
    void testGetFare() {
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));
        when(fareService.calculateFare(train.getDistanceInKm(), "Sleeper")).thenReturn(1500.0);

        double fare = trainController.getFare(1L, "Sleeper");
        assertEquals(1500.0, fare);
        verify(trainRepository, times(1)).findById(1L);
        verify(fareService, times(1)).calculateFare(500, "Sleeper");
    }
}