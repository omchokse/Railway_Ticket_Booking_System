package com.example.train_service.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FareServiceTest {

    private FareService fareService;

    @BeforeEach
    void setUp() {
        fareService = new FareService();
    }

    @Test
    void testCalculateFare_SleeperClass() {
        double fare = fareService.calculateFare(100, "sleeper");
        assertEquals(100.0, fare, "Fare calculation for Sleeper class failed");
    }

    @Test
    void testCalculateFare_ACClass() {
        double fare = fareService.calculateFare(100, "ac");
        assertEquals(200.0, fare, "Fare calculation for AC class failed");
    }

    @Test
    void testCalculateFare_ExecutiveClass() {
        double fare = fareService.calculateFare(100, "executive");
        assertEquals(300.0, fare, "Fare calculation for Executive class failed");
    }

    @Test
    void testCalculateFare_DefaultClass() {
        double fare = fareService.calculateFare(100, "unknownClass");
        assertEquals(100.0, fare, "Fare calculation for default case failed");
    }

    @Test
    void testCalculateFare_ZeroDistance() {
        double fare = fareService.calculateFare(0, "ac");
        assertEquals(0.0, fare, "Fare calculation for zero distance failed");
    }

    @Test
    void testCalculateFare_NegativeDistance() {
        double fare = fareService.calculateFare(-50, "sleeper");
        assertEquals(-50.0, fare, "Fare calculation for negative distance failed");
    }
}