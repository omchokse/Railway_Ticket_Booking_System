package com.example.train_service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;
@Data
@AllArgsConstructor
@Entity
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    @NotEmpty(message = "Train number is required")
    private String trainNumber;

    @Column(nullable = false)
    @NotBlank(message = "Train name is required")
    private String trainName;

    @Column(nullable = false)
    @NotBlank(message = "Source is required")
    private String source;

    @Column(nullable = false)
    @NotBlank(message = "Destination is required")
    private String destination;

    @Column(nullable = false)
    @NotBlank(message = "Departure time is required")
    private String departureTime;

    @Column(nullable = false)
    @NotBlank(message = "Arrival time is required")
    private String arrivalTime;

    @Column(nullable = false)
    @NotNull(message = "Travel date is required")
    @FutureOrPresent(message = "Travel date must be today or in the future")
    private LocalDate travelDate;

    @Column(nullable = false)
    @Positive(message = "Base fare must be positive")
    private double baseFare;

    @Column(nullable = false)
    @Positive(message = "Distance must be positive")
    private double distanceInKm;

    @Min(value = 0, message = "Sleeper seats cannot be negative")
    private int sleeperSeats;

    @Min(value = 0, message = "AC seats cannot be negative")
    private int acSeats;

    @Min(value = 0, message = "Executive seats cannot be negative")
    private int executiveSeats;

    public Train() {
    }
}