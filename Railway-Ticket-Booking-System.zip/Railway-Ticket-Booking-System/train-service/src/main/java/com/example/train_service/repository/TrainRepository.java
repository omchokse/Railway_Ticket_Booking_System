package com.example.train_service.repository;

import com.example.train_service.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface TrainRepository extends JpaRepository<Train, Long> {
}
