package com.example.train_service.controller;

import com.example.train_service.entity.Train;
import com.example.train_service.repository.TrainRepository;
import com.example.train_service.service.FareService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/trains")
@Slf4j
@Validated
public class TrainController {

    @Autowired
    private TrainRepository trainRepository;

    @Autowired
    private FareService fareService;

    @PostMapping
    public Train addTrain(@Valid @RequestBody Train train) {
        try {
            log.info("Train added successfully");
            return trainRepository.save(train);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Failed to add train: " + e.getMessage(), e);
        }
    }

    @GetMapping
    public List<Train> getAllTrains() {
        log.info("All trains fetched successfully");
        return trainRepository.findAll();
    }

    @GetMapping("/{trainId}")
    public Train getTrainById(@PathVariable Long trainId) {
        log.info("Train searched by train Id");
        return trainRepository.findById(trainId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found with ID: " + trainId));
    }

    @GetMapping("/fare/{trainId}/{travelClass}")
    public double getFare(@PathVariable Long trainId, @PathVariable String travelClass) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found with ID: " + trainId));

        try {
            log.info("Fare calculated successfully");
            return fareService.calculateFare(train.getDistanceInKm(), travelClass);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to calculate fare", e);
        }
    }

    @PutMapping("/{trainId}")
    public Train updateTrain(@PathVariable Long trainId, @Valid @RequestBody Train updatedTrain) {
        return trainRepository.findById(trainId)
                .map(train -> {
                    train.setTrainNumber(updatedTrain.getTrainNumber());
                    train.setTrainName(updatedTrain.getTrainName());
                    train.setSource(updatedTrain.getSource());
                    train.setDestination(updatedTrain.getDestination());
                    train.setDepartureTime(updatedTrain.getDepartureTime());
                    train.setArrivalTime(updatedTrain.getArrivalTime());
                    train.setTravelDate(updatedTrain.getTravelDate());
                    train.setBaseFare(updatedTrain.getBaseFare());
                    train.setDistanceInKm(updatedTrain.getDistanceInKm());
                    train.setSleeperSeats(updatedTrain.getSleeperSeats());
                    train.setAcSeats(updatedTrain.getAcSeats());
                    train.setExecutiveSeats(updatedTrain.getExecutiveSeats());
                    log.info("Train info updated successfully");
                    return trainRepository.save(train);
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found with ID: " + trainId));
    }

    @DeleteMapping("/{trainId}")
    public void deleteTrain(@PathVariable Long trainId) {
        if (!trainRepository.existsById(trainId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found with ID: " + trainId);
        }
        trainRepository.deleteById(trainId);
    }

    @PutMapping("/decrease-seats/{trainId}/{seatCount}/{travelClass}")
    public void decreaseSeats(@PathVariable Long trainId, @PathVariable String travelClass, @PathVariable int seatCount) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found"));

        switch (travelClass.toLowerCase()) {
            case "sleeper":
                if (train.getSleeperSeats() < seatCount)
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough sleeper seats");
                train.setSleeperSeats(train.getSleeperSeats() - seatCount);
                break;
            case "ac":
                if (train.getAcSeats() < seatCount)
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough AC seats");
                train.setAcSeats(train.getAcSeats() - seatCount);
                break;
            case "executive":
                if (train.getExecutiveSeats() < seatCount)
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough executive seats");
                train.setExecutiveSeats(train.getExecutiveSeats() - seatCount);
                break;
            default:
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid travel class");
        }

        trainRepository.save(train);
    }

    @PutMapping("/increase-seats/{trainId}/{seatCount}/{travelClass}")
    public void increaseSeats(@PathVariable Long trainId, @PathVariable String travelClass, @PathVariable int seatCount) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found"));

        switch (travelClass.toLowerCase()) {
            case "sleeper":
                train.setSleeperSeats(train.getSleeperSeats() + seatCount);
                break;
            case "ac":
                train.setAcSeats(train.getAcSeats() + seatCount);
                break;
            case "executive":
                train.setExecutiveSeats(train.getExecutiveSeats() + seatCount);
                break;
            default:
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid travel class");
        }

        trainRepository.save(train);
    }
}