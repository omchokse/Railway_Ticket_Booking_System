package com.example.train_service.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class FareService {

    private static final Logger logger = LoggerFactory.getLogger(FareService.class);

    public double calculateFare(double distanceInKm, String travelClass) {
        logger.info("Calculating fare for distance: {} km and travel class: {}", distanceInKm, travelClass);

        if (distanceInKm <= 0) {
            logger.error("Invalid distance: {} km", distanceInKm);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Distance must be greater than zero");
        }

        if (travelClass == null || travelClass.trim().isEmpty()) {
            logger.error("Invalid travel class: {}", travelClass);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Travel class cannot be null or empty");
        }

        double ratePerKm;
        switch (travelClass.toLowerCase()) {
            case "sleeper":
                ratePerKm = 1.0;
                break;
            case "ac":
                ratePerKm = 2.0;
                break;
            case "executive":
                ratePerKm = 3.0;
                break;
            default:
                logger.error("Invalid travel class: {}", travelClass);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid travel class: " + travelClass);
        }

        double fare = distanceInKm * ratePerKm;
        logger.info("Calculated fare: {}", fare);
        return fare;
    }
}