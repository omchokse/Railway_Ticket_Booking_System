package com.example.train_service.service;

import com.example.train_service.entity.Train;
import com.example.train_service.repository.TrainRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class TrainService {

    private static final Logger logger = LoggerFactory.getLogger(TrainService.class);

    @Autowired
    private TrainRepository trainRepository;

    public void decreaseSeats(Long trainId, int seatCount, String travelClass) {
        logger.info("Attempting to decrease {} seats for train ID {} in class {}", seatCount, trainId, travelClass);

        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> {
                    logger.error("Train not found with ID {}", trainId);
                    return new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found");
                });

        switch (travelClass.toUpperCase()) {
            case "SLEEPER":
                if (train.getSleeperSeats() < seatCount) {
                    logger.error("Not enough Sleeper seats for train ID {}", trainId);
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough Sleeper seats");
                }
                train.setSleeperSeats(train.getSleeperSeats() - seatCount);
                break;
            case "AC":
                if (train.getAcSeats() < seatCount) {
                    logger.error("Not enough AC seats for train ID {}", trainId);
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough AC seats");
                }
                train.setAcSeats(train.getAcSeats() - seatCount);
                break;
            case "EXECUTIVE":
                if (train.getExecutiveSeats() < seatCount) {
                    logger.error("Not enough Executive seats for train ID {}", trainId);
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Not enough Executive seats");
                }
                train.setExecutiveSeats(train.getExecutiveSeats() - seatCount);
                break;
            default:
                logger.error("Invalid travel class provided: {}", travelClass);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid travel class");
        }

        trainRepository.save(train);
        logger.info("Successfully decreased {} seats for train ID {} in class {}", seatCount, trainId, travelClass);
    }

    public void increaseSeats(Long trainId, int seatCount, String travelClass) {
        logger.info("Attempting to increase {} seats for train ID {} in class {}", seatCount, trainId, travelClass);

        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> {
                    logger.error("Train not found with ID {}", trainId);
                    return new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found");
                });

        switch (travelClass.toUpperCase()) {
            case "SLEEPER":
                train.setSleeperSeats(train.getSleeperSeats() + seatCount);
                break;
            case "AC":
                train.setAcSeats(train.getAcSeats() + seatCount);
                break;
            case "EXECUTIVE":
                train.setExecutiveSeats(train.getExecutiveSeats() + seatCount);
                break;
            default:
                logger.error("Invalid travel class provided: {}", travelClass);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid travel class");
        }

        trainRepository.save(train);
        logger.info("Successfully increased {} seats for train ID {} in class {}", seatCount, trainId, travelClass);
    }
}