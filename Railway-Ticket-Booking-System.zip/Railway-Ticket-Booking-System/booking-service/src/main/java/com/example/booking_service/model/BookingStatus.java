package com.example.booking_service.model;

public enum BookingStatus {
    NEW,
    CANCELLED
}
