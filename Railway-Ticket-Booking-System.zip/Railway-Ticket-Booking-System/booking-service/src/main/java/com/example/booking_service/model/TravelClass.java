package com.example.booking_service.model;

public enum TravelClass {
    EXECUTIVE,
    SLEEPER,
    AC

}
