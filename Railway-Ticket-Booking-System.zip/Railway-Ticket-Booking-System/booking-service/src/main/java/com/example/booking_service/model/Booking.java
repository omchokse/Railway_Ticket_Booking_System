package com.example.booking_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Travel class must be provided")
    @Enumerated(EnumType.STRING)
    private TravelClass travelClass;

    public TravelClass getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(TravelClass travelClass) {
        this.travelClass = travelClass;
    }

    private String pnr;

    @NotBlank(message = "Passenger name must not be blank")
    @Size(min = 2, max = 100, message = "Passenger name must be between 2 and 100 characters")
    private String passengerName;

    @NotNull(message = "Train ID must be provided")
    private Long trainId;

    @NotNull(message = "User ID must be provided")
    private Long userId;

    @NotNull(message = "Seat count must be provided")
    @Min(value = 1, message = "At least 1 seat must be booked")
    @Max(value = 6, message = "You can only book max 6 seats at a time")
    private Integer seatCount;

    private Double totalFare;

    @Enumerated(EnumType.STRING)
    private BookingStatus status;

}

