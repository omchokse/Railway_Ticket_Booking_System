package com.example.booking_service.service;

import com.example.booking_service.feign.TrainServiceClient;
import com.example.booking_service.model.Booking;
import com.example.booking_service.model.BookingStatus;
import com.example.booking_service.model.TravelClass;
import com.example.booking_service.repository.BookingRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Random;

@Slf4j
@Service
public class BookingService {

    @Autowired
    private TrainServiceClient trainServiceClient;

    @Autowired
    private BookingRepository bookingRepository;

    public Booking bookTicket(Booking booking) {
        try {
            if (booking.getTravelClass() == null) {
                throw new IllegalArgumentException("Travel class must not be null");
            }
            if(booking.getSeatCount()>6){
                throw new IllegalArgumentException("You can only book max 6 seats at a time");
            }
            double totalFare = calculateFare(booking.getTravelClass(),booking.getSeatCount());
            booking.setTotalFare(totalFare);

            // Decrease available seats
            trainServiceClient.decreaseAvailableSeats(
                    booking.getTrainId(),
                    booking.getSeatCount(),
                    booking.getTravelClass().name()
            );

            booking.setStatus(BookingStatus.NEW);
            booking.setPnr(generatePNR());
            log.info("Booking successful");
            return bookingRepository.save(booking);

        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Failed to book ticket: " + e.getMessage(), e);
        }
    }

    public Booking cancelBooking(String pnr) {
        Booking booking = bookingRepository.findByPnr(pnr)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found for PNR: " + pnr));

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Booking already cancelled");
        }

        try {
            booking.setStatus(BookingStatus.CANCELLED);
            Booking cancelledBooking = bookingRepository.save(booking);

            // Increase seats back
            trainServiceClient.increaseAvailableSeats(
                    cancelledBooking.getTrainId(),
                    cancelledBooking.getSeatCount(),
                    cancelledBooking.getTravelClass().name()
            );

            return cancelledBooking;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to cancel booking: " + e.getMessage(), e);
        }
    }

    public Booking getBookingStatus(String pnr) {
        return bookingRepository.findByPnr(pnr)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found for PNR: " + pnr));
    }

    private String generatePNR() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder pnr = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < 6; i++) {
            pnr.append(characters.charAt(rnd.nextInt(characters.length())));
        }
        log.info("PNR number generated");
        return pnr.toString();
    }

    public List<Booking> getAllBookings() {
        try {
            log.info("All Bookings fetched successfully");
            return bookingRepository.findAll();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve bookings", e);
        }
    }
    private double calculateFare(TravelClass travelClass, int seatCount) throws IllegalAccessException {
        double farePerSeat;
        switch (travelClass){
            case AC -> farePerSeat = 1000;
            case SLEEPER -> farePerSeat = 500;
            case EXECUTIVE -> farePerSeat = 1500;
            default -> throw new IllegalAccessException("Unknown travel class");
        }
        log.info("Calculated fare successfully");
        return farePerSeat*seatCount;
    }
}