package com.example.booking_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(name = "train-service")
public interface TrainServiceClient {

    @GetMapping("/trains/fare/{trainId}/{travelClass}")
    Double getFare(@PathVariable Long trainId, @PathVariable String travelClass);

    @PutMapping("/trains/decrease-seats/{trainId}/{seatCount}/{travelClass}")
    void decreaseAvailableSeats(@PathVariable Long trainId, @PathVariable Integer seatCount, @PathVariable String travelClass);

    @PutMapping("/trains/increase-seats/{trainId}/{seatCount}/{travelClass}")
    void increaseAvailableSeats(@PathVariable Long trainId, @PathVariable Integer seatCount,@PathVariable String travelClass);
}
