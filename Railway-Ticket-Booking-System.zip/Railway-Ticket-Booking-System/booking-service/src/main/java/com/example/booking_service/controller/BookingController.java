package com.example.booking_service.controller;

import com.example.booking_service.model.Booking;
import com.example.booking_service.service.BookingService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/book")
    public Booking bookTicket(@Valid @RequestBody Booking booking) {
        try {
            log.info("Booking is successful");
            return bookingService.bookTicket(booking);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Booking failed: " + e.getMessage(), e);
        }
    }

    @PutMapping("/cancel/{pnr}")
    public Booking cancelBooking( @PathVariable String pnr) {
        try {
            log.info("Booking has been cancelled");
            return bookingService.cancelBooking(pnr);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking cancellation failed: " + e.getMessage(), e);
        }
    }

    @GetMapping("/status/{pnr}")
    public Booking getBookingStatus( @PathVariable String pnr) {
        try {
            log.info("Checking status");
            return bookingService.getBookingStatus(pnr);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking status retrieval failed: " + e.getMessage(), e);
        }
    }

    @GetMapping("/all")
    public List<Booking> getAllBookings() {
        try {
            log.info("Fetched all bookings successfully");
            return bookingService.getAllBookings();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve bookings", e);
        }
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleGeneralException(Exception e) {
        return "An error occurred: " + e.getMessage();
    }
}