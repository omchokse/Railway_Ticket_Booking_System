package com.example.booking_service.controller;

import com.example.booking_service.model.Booking;
import com.example.booking_service.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class BookingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private BookingService bookingService;

    @InjectMocks
    private BookingController bookingController;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(bookingController).build();
    }

    @Test
    void bookTicket() throws Exception {
        Booking booking = new Booking();
        booking.setPnr("123ABC");
        when(bookingService.bookTicket(any(Booking.class))).thenReturn(booking);

        mockMvc.perform(post("/booking/book")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"pnr\":\"123ABC\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pnr").value("123ABC"));

        verify(bookingService, times(1)).bookTicket(any(Booking.class));
    }

    @Test
    void cancelBooking() throws Exception {
        Booking booking = new Booking();
        booking.setPnr("123ABC");
        when(bookingService.cancelBooking("123ABC")).thenReturn(booking);

        mockMvc.perform(put("/booking/cancel/123ABC"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pnr").value("123ABC"));

        verify(bookingService, times(1)).cancelBooking("123ABC");
    }

    @Test
    void getBookingStatus() throws Exception {
        Booking booking = new Booking();
        booking.setPnr("123ABC");
        when(bookingService.getBookingStatus("123ABC")).thenReturn(booking);

        mockMvc.perform(get("/booking/status/123ABC"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pnr").value("123ABC"));

        verify(bookingService, times(1)).getBookingStatus("123ABC");
    }

    @Test
    void getAllBookings() throws Exception {
        Booking booking1 = new Booking();
        booking1.setPnr("123ABC");

        Booking booking2 = new Booking();
        booking2.setPnr("456DEF");

        List<Booking> bookings = Arrays.asList(booking1, booking2);
        when(bookingService.getAllBookings()).thenReturn(bookings);

        mockMvc.perform(get("/booking/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(bookingService, times(1)).getAllBookings();
    }
}