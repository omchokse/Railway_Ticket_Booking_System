package com.example.booking_service.service;

import com.example.booking_service.feign.TrainServiceClient;
import com.example.booking_service.model.Booking;
import com.example.booking_service.model.BookingStatus;
import com.example.booking_service.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookingServiceTest {

    @Mock
    private TrainServiceClient trainServiceClient;

    @Mock
    private BookingRepository bookingRepository;

    @InjectMocks
    private BookingService bookingService;

    private Booking booking;

    @BeforeEach
    void setUp() {
        booking = new Booking();
        booking.setPnr("ABC123");
        booking.setStatus(BookingStatus.NEW);
        booking.setTrainId(1L);
        booking.setSeatCount(2);
    }

    @Test
    void testBookTicket() {
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
        Booking savedBooking = bookingService.bookTicket(booking);
        assertNotNull(savedBooking);
        assertEquals(BookingStatus.NEW, savedBooking.getStatus());
        verify(bookingRepository, times(1)).save(any(Booking.class));
    }

    @Test
    void testCancelBooking() {
        when(bookingRepository.findByPnr("ABC123")).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        Booking cancelledBooking = bookingService.cancelBooking("ABC123");
        assertEquals(BookingStatus.CANCELLED, cancelledBooking.getStatus());

        verify(bookingRepository, times(1)).findByPnr("ABC123");
        verify(bookingRepository, times(1)).save(any(Booking.class));
        verify(trainServiceClient, times(1)).increaseAvailableSeats(1L, 2,"AC");
    }

    @Test
    void testCancelBookingAlreadyCancelled() {
        booking.setStatus(BookingStatus.CANCELLED);
        when(bookingRepository.findByPnr("ABC123")).thenReturn(Optional.of(booking));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> bookingService.cancelBooking("ABC123"));
        assertEquals("Booking already cancelled", exception.getMessage());
    }

    @Test
    void testGetBookingStatus() {
        when(bookingRepository.findByPnr("ABC123")).thenReturn(Optional.of(booking));

        Booking foundBooking = bookingService.getBookingStatus("ABC123");
        assertEquals(booking, foundBooking);
        verify(bookingRepository, times(1)).findByPnr("ABC123");
    }

    @Test
    void testGetAllBookings() {
        when(bookingRepository.findAll()).thenReturn(List.of(booking));

        List<Booking> bookings = bookingService.getAllBookings();
        assertFalse(bookings.isEmpty());
        assertEquals(1, bookings.size());
        verify(bookingRepository, times(1)).findAll();
    }
}